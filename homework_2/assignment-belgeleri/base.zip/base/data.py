"""
data.py  –  Dataset loading, splitting, and DataLoader creation.

Supported datasets
------------------
  OGB  : ogbg-molhiv  (scaffold split provided by OGB – do NOT change)
  TU   : PROTEINS, IMDB-MULTI, REDDIT-BINARY  (you implement the split)

TODOs in this file
------------------
  TODO 6 : DataManager._tu_loaders       – stratified train / val / test split
  TODO 7 : DataManager.get_kfold_loaders – k-fold cross-validation
"""

import os
from torch_geometric.loader import DataLoader
from torch_geometric.datasets import TUDataset
from sklearn.model_selection import StratifiedKFold, train_test_split


DATA_ROOT = os.path.join(os.path.dirname(__file__), "data")

OGB_DATASETS = {"ogbg-molhiv", "ogbg-molpcba", "ogbg-moltox21"}
TU_DATASETS  = {"MUTAG", "PROTEINS", "IMDB-MULTI", "REDDIT-BINARY"}


class DataManager:
    """Loads a dataset and creates DataLoaders for train / val / test splits."""

    def __init__(
        self,
        dataset_name: str,
        batch_size  : int = 64,
        num_workers : int = 0,
        seed        : int = 42,
    ):
        self.dataset_name = dataset_name
        self.batch_size   = batch_size
        self.num_workers  = num_workers
        self.seed         = seed

    def get_loaders(self):
        """
        Return (dataset, train_loader, val_loader, test_loader, meta).

        Dispatches to the OGB or TU loader based on dataset name.
        OGB uses the official scaffold split (do not modify).
        TU uses a stratified split you implement in _tu_loaders (TODO 6).
        """
        name = self.dataset_name
        if name.lower() in {d.lower() for d in OGB_DATASETS}:
            return self._ogb_loaders()
        if name.upper() in TU_DATASETS:
            return self._tu_loaders()
        raise ValueError(
            f"Unknown dataset '{name}'. Supported: {OGB_DATASETS | TU_DATASETS}"
        )

    # OGB loader (do not modify – official scaffold split required by assignment)

    def _ogb_loaders(self):
        """Return (dataset, train_loader, val_loader, test_loader, meta) for an OGB dataset."""
        from ogb.graphproppred import PygGraphPropPredDataset

        dataset   = PygGraphPropPredDataset(name=self.dataset_name.lower(), root=DATA_ROOT)
        split_idx = dataset.get_idx_split()

        train_loader = DataLoader(
            dataset[split_idx["train"]], batch_size=self.batch_size,
            shuffle=True,  num_workers=self.num_workers, pin_memory=True
        )
        val_loader = DataLoader(
            dataset[split_idx["valid"]], batch_size=self.batch_size,
            shuffle=False, num_workers=self.num_workers, pin_memory=True
        )
        test_loader = DataLoader(
            dataset[split_idx["test"]], batch_size=self.batch_size,
            shuffle=False, num_workers=self.num_workers, pin_memory=True
        )

        meta = {
            "num_classes"     : dataset.num_classes,
            "num_tasks"       : dataset.num_tasks,
            "node_feat_dim"   : dataset[0].x.shape[1],
            "task_type"       : "classification",
            "metric"          : "rocauc",
            "use_atom_encoder": True,
            "dataset_type"    : "ogb",
        }
        return dataset, train_loader, val_loader, test_loader, meta


    # TODO 6 – TU dataset loader

    def _tu_loaders(self, val_ratio: float = 0.1, test_ratio: float = 0.1):
        """
        Return (dataset, train_loader, val_loader, test_loader, meta) for a TU dataset.

        Steps you need to implement
        ---------------------------
        1. Load the TUDataset. Use `use_node_attr=True`.
           - For datasets WITHOUT node features (dataset[0].x is None), add
             one-hot degree features using OneHotDegree(max_degree).
             Compute max_degree from the dataset before re-loading.

        2. Extract integer labels:  labels = [int(d.y.item()) for d in dataset]

        3. Perform a **stratified** split into train / val / test using
           sklearn.model_selection.train_test_split.
           - First split off `test_ratio` as the test set.
           - Then split the remaining into train / val with effective ratio
             val_ratio / (1 - test_ratio).
           - Use `random_state=self.seed` and `stratify=` in both splits.

        4. Build three DataLoaders (train: shuffle=True, val/test: shuffle=False).

        5. Build and return the `meta` dict with keys:
             num_classes, num_tasks (=1), node_feat_dim, task_type,
             metric ("rocauc" for binary, "accuracy" for multi-class),
             use_atom_encoder (=False), dataset_type (="tu")

        Parameters
        ----------
        val_ratio  : fraction of the full dataset to use for validation
        test_ratio : fraction of the full dataset to use for testing
        """
        # YOUR CODE HERE
        raise NotImplementedError("TODO 6: implement DataManager._tu_loaders")


    # TODO 7 – k-fold cross-validation

    def get_kfold_loaders(self, n_splits: int = 10):
        """
        Yield (fold_idx, train_loader, val_loader, meta) for k-fold cross-validation.
        Intended for small TU datasets where a fixed split is too noisy.

        Steps you need to implement
        ---------------------------
        1. Load the TUDataset (same degree feature handling as _tu_loaders).
        2. Build `labels` array and `meta` dict.
        3. Use StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=self.seed)
           and yield (fold, train_loader, val_loader, meta) for each fold.

        Hint: sklearn's StratifiedKFold.split(X, y) returns (train_idx, val_idx)
              pairs.  Use them to index into `dataset`.

        TODO: Implement this generator.
        """
        # YOUR CODE HERE
        raise NotImplementedError("TODO 7: implement DataManager.get_kfold_loaders")
